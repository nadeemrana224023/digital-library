-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2023 at 04:22 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `notes`
--

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE `uploads` (
  `file_id` int(11) NOT NULL,
  `file_name` varchar(225) NOT NULL,
  `file_description` text NOT NULL,
  `file_type` varchar(225) NOT NULL,
  `file_uploader` varchar(225) NOT NULL,
  `file_uploaded_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `file_uploaded_to` varchar(225) NOT NULL,
  `file` varchar(225) NOT NULL,
  `status` varchar(225) NOT NULL DEFAULT 'not approved yet'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`file_id`, `file_name`, `file_description`, `file_type`, `file_uploader`, `file_uploaded_on`, `file_uploaded_to`, `file`, `status`) VALUES
(3, 'react js', 'JSX', 'docx', 'rajankumar', '2023-01-31 17:34:28', 'Computer Science', '21727.docx', 'approved'),
(4, 'c pop', 'arrays', 'txt', 'nadeemrana', '2023-08-16 02:10:47', 'Computer Science', '826252.txt', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(225) NOT NULL,
  `name` varchar(225) NOT NULL,
  `about` varchar(300) NOT NULL DEFAULT 'N/A',
  `role` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `token` varchar(225) NOT NULL,
  `gender` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `course` varchar(225) NOT NULL,
  `image` varchar(225) NOT NULL DEFAULT 'profile.jpg',
  `joindate` varchar(225) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `about`, `role`, `email`, `token`, `gender`, `password`, `course`, `image`, `joindate`) VALUES
(12, 'root', 'admin root', 'N/A', 'admin', 'root@gmail.com', '', 'N/A', '$2y$10$UExd.f8vQXogrZELXF8KGulQJKUn32p8x4B5SVQ7V/D6.mrSAkAjW', 'Computer Science', 'profile.jpg', '2022-01-01'),
(50, 'harman', 'harmanpreet', 'N/A', 'student', 'harmanpreet@gmail.com', '', 'Male', '$2y$10$QNUTeIZYVAr16wAWEaH5b.ToOCoLU/.0QKdSlzJTA4cH8/F33I122', 'Computer Science', '373419.jpg', 'May 28, 2022'),
(51, 'jatin', 'jatin', 'N/A', 'student', 'jatin@gmail.com', '', 'Male', '$2y$10$CESYRN7y0igd88brlCDbLOcPUPS/6uMtVCJZr05icGLN1RP0W43Le', 'Computer Science', 'profile.jpg', 'May 28, 2022'),
(52, 'satyamdhiman', 'satyam', 'N/A', 'student', 'satyamdhiman@gmail.com', '', 'Male', '$2y$10$UF85VxPo0E0RPYFYagGNWewtBzMZu6Pwn5gKrAHmzY/kuMA2KOqt2', 'Computer Science', 'profile.jpg', 'November 6, 2022'),
(53, 'yashbakshi', 'yashbakshi', 'N/A', 'student', 'yashbakshi@gmail.com', '', 'Male', '$2y$10$.JwAsGgT2vw2snS9SMQKPuiaCTXEwCrGjCr7aZBvABo/X6ctrK.qO', 'Computer Science', 'profile.jpg', 'November 6, 2022'),
(54, 'rajankumar', 'rajan', 'N/A', 'student', 'rajan@gmail.com', '', 'Male', '$2y$10$HnlDaABBYywosQoI/sdg4O8vgT5RLNEId/OOKNXaNpioWTtIKzpw.', 'Computer Science', 'profile.jpg', 'January 31, 2023'),
(55, 'uttamkumar', 'uttam', 'N/A', 'student', 'uttamkumar@gmail.com', '', 'Male', '$2y$10$iYAvBZbW0MreBKM0OzEyFOwmxdJfn3fc9bh.TfLSoBDJ2l368O84a', 'Computer Science', 'profile.jpg', 'January 31, 2023'),
(56, 'parshiv', 'parshiv', 'N/A', 'student', 'parshiv@gmail.com', '', 'Male', '$2y$10$BQnBFXTTBfPxXJbbz3hTQ.upMQniyRUlgSh.3Gb0MZvA56WaXtDYS', 'Computer Science', 'profile.jpg', 'February 5, 2023'),
(57, 'gagankumar', 'gagan', 'N/A', 'student', 'gagan@gmail.com', '', 'Male', '$2y$10$953UXDFftFKTsFERLA/aeeAGi5.C8np60HIDdOTcaKicTneWd2gb2', 'Mechanical', 'profile.jpg', 'February 24, 2023'),
(58, 'nadeemrana', 'nadeem', 'N/A', 'teacher', 'nadeem@gmail.com', '', 'Male', '$2y$10$rRlpW83R0DabDAsI2uEgKOhqdm700uas2dp8/8WEZxEKC/IJTqtaG', 'Computer Science', 'profile.jpg', 'August 16, 2023'),
(59, 'nadeemrana', 'nadeemrana', 'N/A', 'teacher', 'nadeemrana@gmail.com', '', 'Male', '$2y$10$ZlBqs15j6cZKblwHAsphF.aH866Qc.gyRR4gfWg2334h34B0fngay', 'Computer Science', 'profile.jpg', 'August 16, 2023');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
